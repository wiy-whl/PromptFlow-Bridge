(function(){var j=Object.defineProperty;var B=(a,o,e)=>o in a?j(a,o,{enumerable:!0,configurable:!0,writable:!0,value:e}):a[o]=e;var f=(a,o,e)=>B(a,typeof o!="symbol"?o+"":o,e);class P{constructor(){f(this,"lastCapturedText","")}async waitForResponseComplete(o=3e3,e=6e5){return new Promise(t=>{let n="waiting_to_start",i="",s=Date.now();const r=Date.now();let l=!1;const u=this.getResponseContainer(),d=setInterval(()=>{const c=this.checkForHardError();if(c)return clearInterval(d),t({text:null,error:{type:"hard",message:c}});const p=this.getResponseContainer(),m=p?p.innerText.trim():"",h=this.isGenerating();if(h&&(l=!0),h&&p&&p.scrollIntoView({behavior:"auto",block:"end"}),n==="waiting_to_start"){const g=p!==u,S=m!==this.lastCapturedText;if(g||S||h)n="generating",i=m,s=Date.now(),console.log(`[${this.platform}] ⚡ Generation started (Container changed: ${g}, Text changed: ${S}, Stop button: ${h})`);else if(Date.now()-r>9e4)return clearInterval(d),t({text:null,error:{type:"hard",message:"等待新回答超时 (90s)"}})}if(n==="generating")if(h)s=Date.now(),m!==i&&(i=m);else{const g=Date.now()-r;!l&&g<6e3?(s=Date.now(),m!==i&&(i=m)):Date.now()-s>2500&&(n="finishing",s=Date.now(),console.log(`[${this.platform}] 🛑 Stop button definitely gone, entering stabilization...`))}if(n==="finishing"){if(m!==i)i=m,s=Date.now();else if(Date.now()-s>=o&&m.length>5){const L=this.checkForSoftError(m);return L?(clearInterval(d),t({text:m,error:{type:"soft",message:L}})):(clearInterval(d),console.log(`[${this.platform}] ✅ Response complete (${m.length} chars)`),t({text:m}))}}if(Date.now()-r>e)return clearInterval(d),m.length>5?t({text:m}):t({text:null,error:{type:"hard",message:"回答生成超时 (10min)"}})},500)})}async send(){var e;const o=Date.now();for(;Date.now()-o<15e3;){const t=['button[data-testid="send-button"]',".ds-send-button",".msh-chat-input-send","button.send-button",'button[aria-label="Submit"]','button[aria-label="发送"]','button[aria-label="Send"]','button[type="submit"]',".send-button-container"];let n=null;for(const i of t){const s=document.querySelector(i);if(s instanceof HTMLElement){n=s;break}}if(n&&!(n.hasAttribute("disabled")||n.getAttribute("aria-disabled")==="true"||n.classList.contains("disabled"))){n.click(),console.log(`[${this.platform}] 🚀 Clicked Send button`),await new Promise(r=>setTimeout(r,800));const s=document.querySelector('textarea, div[contenteditable="true"]');if(!s||s.value===""||((e=s.innerText)==null?void 0:e.trim())==="")return!0;console.log(`[${this.platform}] 🔄 Textarea not cleared, retrying click...`)}await new Promise(i=>setTimeout(i,500))}return!1}isGenerating(){return['[data-testid="stop-button"]','button[aria-label*="Stop"]','button[aria-label*="停止"]','button[aria-label*="中断"]',".ds-stop-button",".msh-chat-input-stop",'button[title*="停止"]','button[title*="Stop"]',".stop-generating-button"].some(e=>{const t=document.querySelector(e);if(!t)return!1;const n=window.getComputedStyle(t);return n.display!=="none"&&n.visibility!=="hidden"&&!t.disabled})}checkForHardError(){const o=document.body.innerText,e=[{t:"网络错误",c:"network"},{t:"服务器繁忙",c:"server"},{t:"Something went wrong",c:"network"},{t:"触发安全审查",c:"security"},{t:"请求频繁",c:"rate"},{t:"Network error",c:"network"}];for(const t of e)if(o.includes(t.t))return t.t;return document.querySelector(".text-red-500")?"页面出现红色错误提示":null}checkForSoftError(o){const e=[/抱歉|无法回答|AI模型|sorry|unauthorized|blocked/i,/作为.*人工智能/i,/不符合.*政策/i];if(o.length<30){for(const t of e)if(t.test(o))return"模型拒绝回答或触发安全拦截"}return null}getResponseContainer(){return document.querySelector('[data-message-author-role="assistant"]:last-of-type')||document.querySelector(".markdown:last-of-type")||null}simulateInput(o,e){var n;o.focus();const t=(n=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,"value"))==null?void 0:n.set;return t?t.call(o,e):o.value=e,o.dispatchEvent(new Event("input",{bubbles:!0})),o.dispatchEvent(new Event("change",{bubbles:!0})),o.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:e})),!0}getCleanText(o){const e=o.cloneNode(!0);return e.querySelectorAll(".katex-mathml, .MathJax_Preview, script, .katex-a11y").forEach(i=>i.remove()),e.querySelectorAll(".katex-html, .MathJax, .math-display, .math-inline").forEach(i=>{var r;const s=i.getAttribute("data-latex")||((r=i.dataset)==null?void 0:r.latex)||i.getAttribute("aria-label");s&&(i.textContent=` ${s} `)}),e.querySelectorAll("br").forEach(i=>i.replaceWith(`
`)),e.innerText.trim()}async waitForElement(o,e=15e3){const t=Date.now();for(;Date.now()-t<e;){const n=document.querySelector(o);if(n instanceof HTMLElement)return n;await new Promise(i=>setTimeout(i,500))}return null}async waitForAnySelector(o,e=15e3){const t=Date.now();for(;Date.now()-t<e;){for(const n of o){const i=document.querySelector(n);if(i instanceof HTMLElement)return i}await new Promise(n=>setTimeout(n,500))}return null}}class G extends P{constructor(){super(...arguments);f(this,"platform","deepseek")}detect(){return window.location.hostname.includes("deepseek.com")}capture(e){var i;const t=(e==null?void 0:e.closest(".ds-markdown"))||(e==null?void 0:e.closest(".markdown"))||document.querySelector(".ds-markdown:last-of-type")||document.querySelector(".markdown:last-of-type");if(!t)return null;let n=t.getAttribute("data-content")||"";if(!n){const s=(i=t.parentElement)==null?void 0:i.querySelector("[data-clipboard-text]");n=(s==null?void 0:s.getAttribute("data-clipboard-text"))||""}return n||(n=this.getCleanText(t)),{content:n,sourceModel:this.platform,hasLaTeX:n.includes("$")||n.includes("\\"),timestamp:Date.now()}}async inject(e){const t=await this.waitForElement("textarea#chat-input")||await this.waitForElement("textarea");if(!t)return!1;const n=this.simulateInput(t,e);return t.dispatchEvent(new Event("input",{bubbles:!0})),n}async send(){var i;const e=this.getResponseContainer();this.lastCapturedText=e?e.innerText.trim():"";const t=Date.now();for(;Date.now()-t<8e3;){const s=document.querySelector('div[role="button"][aria-label="Send"]')||document.querySelector('div[role="button"][aria-label="发送"]')||document.querySelector(".ds-send-button")||((i=document.querySelector('div[style*="cursor: pointer"] svg'))==null?void 0:i.parentElement);if(s instanceof HTMLElement){if(s.getAttribute("aria-disabled")==="true"||s.hasAttribute("disabled")){await new Promise(u=>setTimeout(u,100));continue}s.click();const r=Date.now();let l=!1;for(;Date.now()-r<1e3;){const u=document.querySelector("textarea#chat-input")||document.querySelector("textarea");if(!u||u.innerText.trim()===""||u.value===""){l=!0;break}await new Promise(d=>setTimeout(d,100))}if(l)return!0}await new Promise(r=>setTimeout(r,100))}const n=document.querySelector("textarea#chat-input")||document.querySelector("textarea");return n instanceof HTMLTextAreaElement?(n.focus(),n.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0,ctrlKey:!1})),!0):!1}getResponseContainer(){return document.querySelector(".ds-markdown:last-of-type")||document.querySelector(".markdown:last-of-type")||null}}class O extends P{constructor(){super(...arguments);f(this,"platform","kimi")}detect(){const e=window.location.hostname;return e.includes("kimi.moonshot.cn")||e.includes("kimi.ai")||e.includes("kimi.com")}capture(e){var r,l,u;const t=(e==null?void 0:e.closest(".markdown-content"))||(e==null?void 0:e.closest(".markdown"))||document.querySelector(".markdown:last-of-type")||document.querySelector(".markdown-content:last-of-type");if(!t)return null;const n=((l=(r=t.parentElement)==null?void 0:r.parentElement)==null?void 0:l.querySelector(".message-footer"))||((u=t.parentElement)==null?void 0:u.querySelector(".message-footer")),i=n==null?void 0:n.querySelector("[data-clipboard-text]");let s=(i==null?void 0:i.getAttribute("data-clipboard-text"))||"";return s||(s=this.getCleanText(t)),{content:s.trim(),sourceModel:this.platform,hasLaTeX:s.includes("$")||s.includes("\\"),timestamp:Date.now()}}async inject(e){const t=await this.waitForElement(".chat-input-editor")||await this.waitForElement(".msh-chat-input-editor")||await this.waitForElement('div[contenteditable="true"]');return t?t instanceof HTMLTextAreaElement?this.simulateInput(t,e):(t.focus(),document.execCommand("selectAll",!1),document.execCommand("delete",!1),document.execCommand("insertText",!1,e),t.dispatchEvent(new Event("input",{bubbles:!0})),!0):!1}async send(){const e=this.getResponseContainer();this.lastCapturedText=e?e.innerText.trim():"";const t=Date.now();for(;Date.now()-t<8e3;){const n=document.querySelector(".send-button-container")||document.querySelector(".msh-chat-input-send")||document.querySelector('button[title="发送"]')||document.querySelector("button.send-button");if(n instanceof HTMLElement){if(n.hasAttribute("disabled")){await new Promise(r=>setTimeout(r,100));continue}n.click();const i=Date.now();let s=!1;for(;Date.now()-i<1e3;){const r=document.querySelector(".chat-input-editor")||document.querySelector(".msh-chat-input-editor")||document.querySelector('div[contenteditable="true"]');if(!r||r.innerText.trim()===""||r.value===""){s=!0;break}await new Promise(l=>setTimeout(l,100))}if(s)return!0}await new Promise(i=>setTimeout(i,100))}return!1}getResponseContainer(){return document.querySelector(".markdown-content:last-of-type")||document.querySelector(".markdown:last-of-type")||null}}class z extends P{constructor(){super(...arguments);f(this,"platform","gemini")}detect(){return window.location.hostname.includes("gemini.google.com")||window.location.href.includes("google.com/gemini")}getShadowEditor(){var e,t;try{const n=document.querySelector("gemini-app"),i=(e=n==null?void 0:n.shadowRoot)==null?void 0:e.querySelector("message-input");return((t=i==null?void 0:i.shadowRoot)==null?void 0:t.querySelector('div[contenteditable="true"], .rich-text-editor'))||null}catch{return null}}getShadowSendButton(){var e,t;try{const n=document.querySelector("gemini-app"),i=(e=n==null?void 0:n.shadowRoot)==null?void 0:e.querySelector("message-input");return((t=i==null?void 0:i.shadowRoot)==null?void 0:t.querySelector('button.send-button, [aria-label*="Send"], [aria-label*="发送"]'))||null}catch{return null}}capture(e){const t=(e==null?void 0:e.closest(".model-response-text"))||(e==null?void 0:e.closest("message-content"))||this.getResponseContainer();if(!t)return null;const n=this.getCleanText(t);return{content:n,sourceModel:this.platform,hasLaTeX:n.includes("$")||n.includes("\\"),timestamp:Date.now()}}getLastResponseEl(){const e=["model-response:last-of-type .model-response-text",".model-response-text:last-of-type","message-content:last-of-type"];for(const t of e){const n=document.querySelector(t);if(n&&n.innerText.trim().length>5)return n}return this.getResponseContainer()}async inject(e){let t=null;const n=Date.now(),i=15e3;for(;Date.now()-n<i&&(t=this.getShadowEditor(),!t);){const r=document.querySelector('div[contenteditable="true"][role="textbox"]');if(r instanceof HTMLElement){t=r;break}await new Promise(l=>setTimeout(l,500))}if(!t)return console.warn("[Gemini] Editor not found in shadow root or light DOM"),!1;t.focus(),document.execCommand("selectAll",!1),document.execCommand("delete",!1),t.innerHTML="";try{const r=new DataTransfer;r.setData("text/plain",e);const l=new ClipboardEvent("paste",{clipboardData:r,bubbles:!0,cancelable:!0,composed:!0});t.dispatchEvent(l),await new Promise(u=>setTimeout(u,1500)),t.innerText.trim().length<e.length*.5&&document.execCommand("insertText",!1,e)}catch{document.execCommand("insertText",!1,e)}const s={bubbles:!0,composed:!0};return["input","change","blur","keyup"].forEach(r=>{t.dispatchEvent(new Event(r,s))}),!0}async send(){var n,i;const e=this.getLastResponseEl();this.lastCapturedText=e?e.innerText.trim():"";const t=Date.now();for(;Date.now()-t<8e3;){const s=this.getShadowSendButton()||document.querySelector("button.send-button")||document.querySelector('button[aria-label*="Send"]')||document.querySelector('button[aria-label*="发送"]')||((i=(n=document.querySelector("message-input"))==null?void 0:n.shadowRoot)==null?void 0:i.querySelector("button"));if(s instanceof HTMLElement){if(s.hasAttribute("disabled")){await new Promise(u=>setTimeout(u,100));continue}s.click();const r=Date.now();let l=!1;for(;Date.now()-r<1e3;){const u=this.getShadowEditor()||document.querySelector('div[contenteditable="true"][role="textbox"]');if(!u||u.innerText.trim()===""||u.innerHTML.trim()==="<p><br></p>"){l=!0;break}await new Promise(d=>setTimeout(d,100))}if(l)return!0}await new Promise(r=>setTimeout(r,100))}return!1}isGenerating(){var e,t;try{const n=document.querySelector("gemini-app"),i=(e=n==null?void 0:n.shadowRoot)==null?void 0:e.querySelector("message-input"),s=(t=i==null?void 0:i.shadowRoot)==null?void 0:t.querySelector('button.stop-button, [aria-label*="Stop"], [aria-label*="停止"]');if(s instanceof HTMLElement){const r=window.getComputedStyle(s);return r.display!=="none"&&r.visibility!=="hidden"&&!s.disabled}}catch{}return super.isGenerating()}getResponseContainer(){var t,n;try{const i=document.querySelector("gemini-app"),s=(t=i==null?void 0:i.shadowRoot)==null?void 0:t.querySelectorAll("model-response");if(s&&s.length>0){const r=s[s.length-1];return((n=r.shadowRoot)==null?void 0:n.querySelector(".message-content, .model-response-text"))||r.querySelector(".message-content, .model-response-text")||r}}catch{}const e=document.querySelectorAll("model-response");if(e.length>0){const i=e[e.length-1];return i.querySelector(".model-response-text")||i.querySelector("message-content")||i}return null}}class H extends P{constructor(){super(...arguments);f(this,"platform","gpt")}detect(){const e=window.location.hostname.toLowerCase();return e.includes("chatgpt.com")||e.includes("openai.com")}capture(e){const t=document.querySelectorAll('[data-message-author-role="assistant"]'),n=t[t.length-1],i=(e==null?void 0:e.closest(".markdown"))||(e==null?void 0:e.closest('[data-message-author-role="assistant"]'))||(n==null?void 0:n.querySelector(".markdown"))||n||document.querySelector(".markdown:last-of-type");if(!i)return null;const s=this.getCleanText(i);return{content:s,sourceModel:this.platform,hasLaTeX:s.includes("$")||s.includes("\\"),timestamp:Date.now()}}async inject(e){const t=["#prompt-textarea",'[contenteditable="true"]',"textarea",".ProseMirror"],n=await this.waitForAnySelector(t,15e3);if(!n)return console.warn("[ChatGPT] Editor not found after multiple attempts"),!1;try{if(n.focus(),await new Promise(s=>setTimeout(s,500)),document.execCommand("selectAll",!1),document.execCommand("delete",!1),!document.execCommand("insertText",!1,e)){const s=new DataTransfer;s.setData("text/plain",e),n.dispatchEvent(new ClipboardEvent("paste",{clipboardData:s,bubbles:!0,cancelable:!0}))}return n.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:e})),!0}catch(i){return console.error("[ChatGPT] Injection error:",i),!1}}async send(){const e=Date.now();for(;Date.now()-e<15e3;){const t=document.querySelector('[data-testid="send-button"]')||document.querySelector('button[data-testid="send-button"]')||document.querySelector('button[aria-label="发送提示"]')||document.querySelector('button[aria-label="Send prompt"]')||document.querySelector("#composer-submit-button")||document.querySelector("button.absolute.bottom-1\\.5");if(t instanceof HTMLElement&&!(t.hasAttribute("disabled")||t.getAttribute("aria-disabled")==="true"||t.classList.contains("disabled"))){t.click(),console.log("[ChatGPT] 🚀 Clicked Send button"),await new Promise(s=>setTimeout(s,1e3));const i=document.querySelector("#prompt-textarea")||document.querySelector('[contenteditable="true"]');if(!i||i.innerText.trim()===""||i.innerHTML.trim()==="<p><br></p>")return!0}await new Promise(n=>setTimeout(n,500))}return!1}getResponseContainer(){return document.querySelector('[data-message-author-role="assistant"]:last-of-type .markdown')||document.querySelector('[data-message-author-role="assistant"]:last-of-type')||document.querySelector(".markdown:last-of-type")||null}}class U extends P{constructor(){super(...arguments);f(this,"platform","grok")}detect(){const e=window.location.hostname;return e.includes("grok.com")||e==="x.com"}capture(e){const t=(e==null?void 0:e.closest('[data-testid="assistant-message"]'))||(e==null?void 0:e.closest('[data-testid="tweetText"]'))||(e==null?void 0:e.closest(".prose"))||(e==null?void 0:e.closest('[data-testid="model-response"]'))||(e==null?void 0:e.closest('[data-testid="messageEntry"]'))||(e==null?void 0:e.closest('[aria-label*="Grok"]'))||(e==null?void 0:e.closest('[class*="response"]'))||document.querySelector('[data-testid="assistant-message"]:last-of-type')||document.querySelector('[data-testid="tweetText"]:last-of-type')||document.querySelector('[data-testid="messageEntry"]:last-of-type')||document.querySelector(".prose:last-of-type");if(!t)return null;const n=this.getCleanText(t);return t.style.outline="2px solid #1d9bf0",setTimeout(()=>{t.style.outline=""},1e3),{content:n,sourceModel:this.platform,hasLaTeX:n.includes("$")||n.includes("\\"),timestamp:Date.now()}}async inject(e){const t=["div.tiptap.ProseMirror",'div[data-testid="tweetTextarea_0"]','div[contenteditable="true"][role="textbox"]','div[contenteditable="true"]'],n=await this.waitForAnySelector(t,15e3);if(!n)return console.warn("[Grok] ProseMirror editor not found"),!1;try{if(n.focus(),document.execCommand("selectAll",!1),document.execCommand("delete",!1),!document.execCommand("insertText",!1,e)){const s=new DataTransfer;s.setData("text/plain",e),n.dispatchEvent(new ClipboardEvent("paste",{clipboardData:s,bubbles:!0,cancelable:!0}))}return n.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:e})),!0}catch(i){return console.error("[Grok] Injection error:",i),!1}}async send(){const e=this.getResponseContainer();this.lastCapturedText=e?e.innerText.trim():"";const t=Date.now();for(;Date.now()-t<8e3;){const n=document.querySelector('button[data-testid="send-button"]')||document.querySelector('button[data-testid="tweetButtonInline"]')||document.querySelector('button[aria-label="提交"]')||document.querySelector('button[aria-label="Submit"]')||document.querySelector('button[type="submit"]')||document.querySelector('button[aria-label="Send message"]')||document.querySelector('[data-testid="grok-send-button"]')||document.querySelector("button.bg-primary-500")||document.querySelector('div[role="button"][aria-label="Send"]');if(n instanceof HTMLElement){if(n.hasAttribute("disabled")){await new Promise(r=>setTimeout(r,100));continue}n.click();const i=Date.now();let s=!1;for(;Date.now()-i<1e3;){const r=document.querySelector("div.tiptap.ProseMirror")||document.querySelector('div[contenteditable="true"]');if(!r||r.innerText.trim()===""||r.innerHTML.trim()==="<p></p>"){s=!0;break}await new Promise(l=>setTimeout(l,100))}if(s)return!0}await new Promise(i=>setTimeout(i,100))}return console.warn("[Grok] Send button not found, disabled, or click swallowed"),!1}getResponseContainer(){const e=document.querySelectorAll('[data-testid="assistant-message"]');if(e.length>0)return e[e.length-1];const t=document.querySelectorAll('[data-testid="tweetText"]');if(t.length>0)return t[t.length-1];const n=document.querySelectorAll('[data-testid="model-response"]');if(n.length>0)return n[n.length-1];const i=document.querySelectorAll(".prose");if(i.length>0)return i[i.length-1];const s=document.querySelectorAll('[class*="response"]');return s.length>0?s[s.length-1]:null}}const v=[{id:"deepseek",name:"DeepSeek",color:"#3B82F6",char:"D"},{id:"kimi",name:"Kimi",color:"#8B5CF6",char:"K"},{id:"gemini",name:"Gemini",color:"#F59E0B",char:"G"},{id:"gpt",name:"ChatGPT",color:"#10B981",char:"C"},{id:"grok",name:"Grok",color:"#FFFFFF",char:"X"}],k={blur:"32px",glassBase:"rgba(28, 28, 30, 0.7)",border:"1px solid rgba(255, 255, 255, 0.12)",shadow:"0 20px 80px rgba(0, 0, 0, 0.7)",curve:"cubic-bezier(0.34, 1.56, 0.64, 1)"},V=`
  #pfb-container { display: flex; flex-direction: column; align-items: flex-end; pointer-events: none; }
  
  #pfb-orb {
    position: relative; width: 52px; height: 52px; border-radius: 26px;
    background: ${k.glassBase}; backdrop-filter: blur(${k.blur});
    border: ${k.border}; box-shadow: ${k.shadow};
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    transition: all 0.5s ${k.curve}; pointer-events: auto;
  }
  #pfb-orb.running { width: 140px; border-radius: 18px; }

  #pfb-panel {
    position: absolute; bottom: 72px; right: 0; width: 280px;
    background: rgba(22, 22, 24, 0.85); backdrop-filter: blur(50px);
    border: ${k.border}; border-radius: 28px; padding: 18px;
    transition: all 0.5s ${k.curve}; transform-origin: bottom right; pointer-events: auto;
    box-shadow: ${k.shadow};
  }
  #pfb-panel.hidden { opacity: 0; visibility: hidden; transform: scale(0.8) translateY(40px); }

      .pfb-settings-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 12px;
        padding: 0 4px;
        font-size: 11px;
        color: #aaa;
      }
      .pfb-toggle-group {
        display: flex;
        background: rgba(255,255,255,0.05);
        border-radius: 6px;
        padding: 2px;
        border: 1px solid rgba(255,255,255,0.1);
      }
      .pfb-toggle-btn {
        padding: 4px 10px;
        border-radius: 4px;
        border: none;
        background: transparent;
        color: #888;
        cursor: pointer;
        font-size: 10px;
        transition: all 0.2s;
        font-weight: 500;
      }
      .pfb-toggle-btn:hover {
        color: #fff;
      }
      .pfb-toggle-btn.active {
        background: rgba(255,255,255,0.15);
        color: #fff;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      }
      .section-title {
        font-size: 10px;
        font-weight: 700;
        color: #666;
        margin-bottom: 8px;
        letter-spacing: 1px;
        text-transform: uppercase;
      }

  /* ── Single Inject Grid ── */
  #pfb-model-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 16px; }
  .model-btn {
    aspect-ratio: 1; border-radius: 12px; border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.03); cursor: pointer; display: flex; align-items: center;
    justify-content: center; font-weight: 900; color: white; transition: all 0.2s; font-size: 14px;
  }
  .model-btn:hover { background: rgba(255,255,255,0.1); transform: translateY(-2px); border-color: rgba(255,255,255,0.2); }

  /* ── Pipeline Items ── */
  .pipeline-item {
    width: 100%; display: flex; flex-direction: column; gap: 4px; padding: 12px;
    border: none; background: rgba(255,255,255,0.02); border-radius: 16px; margin-bottom: 8px;
    cursor: pointer; color: white; border: 1px solid transparent; transition: all 0.3s;
    position: relative;
  }
  .pipeline-item:hover { background: rgba(255,255,255,0.08); border-color: rgba(255,255,255,0.1); }
  
  /* Recommended Pipeline Pulse Glow */
  .pipeline-item.recommended {
    border: 1px solid rgba(139, 92, 246, 0.4) !important;
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.08) 0%, rgba(139, 92, 246, 0.12) 100%) !important;
    box-shadow: 0 0 16px rgba(139, 92, 246, 0.25);
    animation: pfb-pulse-glow 2.5s infinite alternate ease-in-out;
  }
  
  @keyframes pfb-pulse-glow {
    0% {
      border-color: rgba(139, 92, 246, 0.3);
      box-shadow: 0 0 12px rgba(139, 92, 246, 0.15);
    }
    100% {
      border-color: rgba(59, 130, 246, 0.6);
      box-shadow: 0 0 20px rgba(59, 130, 246, 0.35);
    }
  }

  /* Dynamically Assembled Pipeline Gold-Purple流光 Glow */
  .pipeline-item.dynamic-assembled {
    border: 1px solid rgba(245, 158, 11, 0.45) !important;
    background: linear-gradient(135deg, rgba(245, 158, 11, 0.08) 0%, rgba(139, 92, 246, 0.12) 100%) !important;
    box-shadow: 0 0 20px rgba(245, 158, 11, 0.2);
    animation: pfb-dynamic-glow 3s infinite alternate ease-in-out;
  }
  
  @keyframes pfb-dynamic-glow {
    0% {
      border-color: rgba(245, 158, 11, 0.35);
      box-shadow: 0 0 12px rgba(245, 158, 11, 0.15);
    }
    50% {
      border-color: rgba(139, 92, 246, 0.5);
      box-shadow: 0 0 16px rgba(139, 92, 246, 0.2);
    }
    100% {
      border-color: rgba(245, 158, 11, 0.65);
      box-shadow: 0 0 24px rgba(245, 158, 11, 0.35);
    }
  }

  /* Dynamic assembled AI Badge */
  .ai-badge.gold {
    background: linear-gradient(135deg, #F59E0B 0%, #8B5CF6 100%);
    box-shadow: 0 2px 6px rgba(245, 158, 11, 0.4);
  }
  
  .pipeline-item.dynamic-assembled:hover .recommended-tooltip {
    opacity: 1;
    visibility: visible;
    transform: translateY(-50%) translateX(0);
  }

  /* Recommended AI Badge */
  .ai-badge {
    font-size: 8px;
    font-weight: 900;
    color: #ffffff;
    background: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%);
    padding: 2px 5px;
    border-radius: 6px;
    letter-spacing: 0.5px;
    margin-left: 6px;
    box-shadow: 0 2px 6px rgba(139, 92, 246, 0.4);
    animation: pfb-badge-shimmer 2s infinite ease-in-out;
    display: inline-flex;
    align-items: center;
    vertical-align: middle;
  }

  @keyframes pfb-badge-shimmer {
    0%, 100% { opacity: 0.9; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.05); }
  }

  /* Tooltip Rationale styling */
  .recommended-tooltip {
    position: absolute;
    top: 50%;
    transform: translateY(-50%) translateX(10px);
    right: 290px;
    width: 250px;
    padding: 12px 14px;
    background: rgba(18, 18, 20, 0.95);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    color: #e4e4e7;
    font-size: 11px;
    line-height: 1.5;
    z-index: 99999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    pointer-events: none;
    text-align: left;
    white-space: normal;
  }
  
  .pipeline-item.recommended:hover .recommended-tooltip {
    opacity: 1;
    visibility: visible;
    transform: translateY(-50%) translateX(0);
  }
  
  .item-header { display: flex; align-items: center; justify-content: space-between; width: 100%; }
  .item-name { font-size: 13px; font-weight: 700; display: flex; align-items: center; }
  .item-steps { display: flex; align-items: center; gap: 4px; opacity: 0.6; }
  .step-dot { width: 14px; height: 14px; border-radius: 4px; font-size: 8px; display: flex; align-items: center; justify-content: center; font-weight: 900; color: black; }
  .step-arrow { font-size: 8px; opacity: 0.4; }

  #pfb-toast {
    position: absolute; bottom: 72px; right: 0; padding: 10px 24px;
    background: rgba(10, 10, 12, 0.95); backdrop-filter: blur(40px);
    border-radius: 50px; font-size: 13px; font-weight: 700; color: white;
    transform: translateY(20px); opacity: 0; visibility: hidden; transition: 0.4s;
  }
  #pfb-toast.visible { opacity: 1; visibility: visible; transform: translateY(0); }

  /* ── Template Select Menu ── */
  .pfb-tpl-select-btn {
    width: 100%; text-align: left; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05);
    border-radius: 12px; padding: 10px 14px; color: white; cursor: pointer; font-size: 12px; font-weight: 500;
    transition: all 0.2s; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; box-sizing: border-box;
    font-family: inherit; margin-bottom: 2px;
  }
  .pfb-tpl-select-btn:hover { background: rgba(255,255,255,0.1) !important; border-color: rgba(255,255,255,0.15) !important; transform: translateY(-1px); }
  #pfb-tpl-back-btn:hover { color: white !important; }
  #pfb-free-send-btn:hover {
    opacity: 0.9;
    transform: translateY(-1px);
    box-shadow: 0 6px 16px rgba(255,255,255,0.15) !important;
  }
  #pfb-free-cancel-btn:hover {
    background: rgba(255,255,255,0.1) !important;
    border-color: rgba(255,255,255,0.15) !important;
    color: white !important;
    transform: translateY(-1px);
  }
`;class K{constructor(){f(this,"host");f(this,"shadow");f(this,"orb",null);f(this,"panel",null);f(this,"status","idle");f(this,"isOpen",!1);f(this,"pipelines",[]);f(this,"templates",[]);f(this,"selectedModelForTemplate",null);f(this,"isFreeInputMode",!1);f(this,"capturedSelectionText","");f(this,"recommendedPipeline",null);this.host=document.createElement("div"),this.host.className="pfb-dynamic-island-host",this.forcePosition(),this.shadow=this.host.attachShadow({mode:"open"}),document.body.appendChild(this.host),this.render(),this.initInteractions(),this.initKeyboard(),this.loadPipelines(),this.loadTemplates().then(()=>{this.renderQuickInject()}),this.listenToEvents(),this.syncState(),this.loadSettings(),document.addEventListener("mouseup",()=>{setTimeout(()=>{var e;const o=(e=window.getSelection())==null?void 0:e.toString().trim();o&&(this.capturedSelectionText=o)},0)})}forcePosition(){const o=this.host.style;o.setProperty("position","fixed","important"),o.setProperty("right","48px","important"),o.setProperty("bottom","120px","important"),o.setProperty("z-index","2147483647","important"),o.setProperty("pointer-events","none","important"),o.setProperty("display","block","important")}async loadSettings(){var o,e;try{if(!((o=chrome==null?void 0:chrome.storage)!=null&&o.local)||!((e=chrome==null?void 0:chrome.runtime)!=null&&e.id))return;const{pfb_session_mode:t}=await chrome.storage.local.get(["pfb_session_mode"]);t&&this.updateSessionModeUI(t)}catch{console.warn("[Relay] Context invalidated during loadSettings")}}updateSessionModeUI(o){this.shadow.querySelectorAll("#pfb-session-mode .pfb-toggle-btn").forEach(t=>{t.getAttribute("data-mode")===o?t.classList.add("active"):t.classList.remove("active")})}render(){this.shadow.innerHTML=`<style>${V}</style>
      <div id="pfb-container">
        <div id="pfb-toast"></div>
        <div id="pfb-panel" class="hidden">
          <div class="pfb-settings-row">
            <label>链路模式</label>
            <div class="pfb-toggle-group" id="pfb-session-mode">
              <button class="pfb-toggle-btn active" data-mode="continue" title="在当前对话继续">继续</button>
              <button class="pfb-toggle-btn" data-mode="new" title="每次接力开新对话">新对话</button>
            </div>
          </div>
          
          <div id="pfb-quick-inject-section">
            <div class="section-title">QUICK INJECT</div>
            <div id="pfb-model-grid">
              ${v.map(t=>`<button class="model-btn" data-model="${t.id}" style="color:${t.color}">${t.char}</button>`).join("")}
            </div>
          </div>

          <div class="section-title">
            <span>RELAY PIPELINES</span>
            <span id="pfb-reset" style="cursor:pointer; color:#ef4444;">RESET</span>
          </div>
          <div id="pfb-list"></div>
        </div>
        <div id="pfb-orb" class="${this.status}">
          <svg style="width:24px; height:24px; stroke:white; stroke-width:2.5; z-index:10;" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
      </div>`,this.orb=this.shadow.getElementById("pfb-orb"),this.panel=this.shadow.getElementById("pfb-panel"),this.shadow.querySelectorAll("#pfb-session-mode .pfb-toggle-btn").forEach(t=>{t.addEventListener("click",async()=>{var n,i;try{if(!((n=chrome==null?void 0:chrome.runtime)!=null&&n.id))throw new Error("Context invalidated");const s=t.getAttribute("data-mode");s&&((i=chrome==null?void 0:chrome.storage)!=null&&i.local)&&(await chrome.storage.local.set({pfb_session_mode:s}),this.updateSessionModeUI(s),this.showToast(`已切换至「${s==="new"?"新对话":"继续对话"}」模式`))}catch{this.showToast("⚠️ 插件已失效，请刷新页面重试",5e3)}})});const e=this.shadow.getElementById("pfb-reset");e==null||e.addEventListener("mousedown",t=>t.preventDefault()),e==null||e.addEventListener("click",async t=>{var n;t.stopPropagation();try{if(!((n=chrome==null?void 0:chrome.runtime)!=null&&n.id))throw new Error("Context invalidated");this.setStatus("idle"),await chrome.storage.local.remove(["pfb_pipeline_state"]),this.showToast("♻️ System Cleared")}catch{this.showToast("⚠️ 插件已失效，请刷新页面",5e3)}}),this.renderQuickInject()}async loadTemplates(){var o,e;try{if(!((o=chrome==null?void 0:chrome.storage)!=null&&o.local)||!((e=chrome==null?void 0:chrome.runtime)!=null&&e.id))return;const t=await chrome.storage.local.get(["pfb_templates"]);this.templates=t.pfb_templates||[]}catch(t){console.warn("[Relay] Failed to load templates:",t)}}renderQuickInject(){var e,t;const o=this.shadow.getElementById("pfb-quick-inject-section");if(o)if(!this.selectedModelForTemplate)o.innerHTML=`
        <div class="section-title">QUICK INJECT</div>
        <div id="pfb-model-grid">
          ${v.map(n=>`<button class="model-btn" data-model="${n.id}" style="color:${n.color}">${n.char}</button>`).join("")}
        </div>
      `,o.querySelectorAll(".model-btn").forEach(n=>{n.addEventListener("mousedown",i=>i.preventDefault()),n.addEventListener("click",i=>{var r;const s=i.currentTarget.dataset.model;if(s){const l=(r=window.getSelection())==null?void 0:r.toString().trim();l&&(this.capturedSelectionText=l),this.templates.filter(d=>d.targetModel===s).length===0?(this.close(),this.showToast(`⚡ 正在抓取并直接接力至 ${s.toUpperCase()}...`),document.dispatchEvent(new CustomEvent("pfb:relay-request",{bubbles:!0,composed:!0,detail:{targetModel:s,skipTemplate:!0,capturedContent:this.capturedSelectionText}}))):(this.selectedModelForTemplate=s,this.isFreeInputMode=!1,this.renderQuickInject())}})});else if(this.isFreeInputMode){const n=this.selectedModelForTemplate,i=this.getBrandingColor(n),s=((t=v.find(p=>p.id===n))==null?void 0:t.name)||n,r=this.capturedSelectionText?`输入你的追加指令（已安全缓存选中的 ${this.capturedSelectionText.length} 字网页内容作为上下文）...`:"输入指令或问题，快捷抓取网页并接力...";o.innerHTML=`
        <div class="pfb-template-select-header" style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
          <button id="pfb-tpl-back-btn" style="background:transparent; border:none; color:#8E8E93; cursor:pointer; font-size:12px; padding:4px 0; display:flex; align-items:center; gap:4px; font-weight:700;">
            ← 返回
          </button>
          <span style="font-size:10px; font-weight:700; color:${i}; letter-spacing:1px; text-transform:uppercase;">
            自由输入 (${s})
          </span>
        </div>
        <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:16px;">
          <textarea id="pfb-free-textarea" placeholder="${r}" rows="3" style="width:100%; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); border-radius:12px; padding:10px 12px; color:white; font-size:12px; font-family:inherit; resize:none; outline:none; box-sizing:border-box; transition:all 0.3s; line-height:1.5;"></textarea>
          <div style="display:flex; gap:8px; width:100%; box-sizing:border-box;">
            <button id="pfb-free-cancel-btn" style="flex:1; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.08); border-radius:12px; padding:10px; color:#8E8E93; cursor:pointer; font-size:12px; font-weight:700; transition:all 0.2s; box-sizing:border-box; font-family:inherit; border-color:rgba(255,255,255,0.05);">
              取消
            </button>
            <button id="pfb-free-send-btn" style="flex:2; background:${i}; border:none; border-radius:12px; padding:10px; color:white; cursor:pointer; font-size:12px; font-weight:700; transition:all 0.2s; box-shadow:0 4px 12px rgba(255,255,255,0.1); box-sizing:border-box; font-family:inherit; display:flex; align-items:center; justify-content:center; gap:4px;">
              🚀 确认发送
            </button>
          </div>
        </div>
      `;const l=this.shadow.getElementById("pfb-free-textarea");l&&(l.focus(),l.addEventListener("focus",()=>{l.style.borderColor="rgba(59,130,246,0.5)",l.style.boxShadow="0 0 8px rgba(59,130,246,0.2)"}),l.addEventListener("blur",()=>{l.style.borderColor="rgba(255,255,255,0.08)",l.style.boxShadow="none"}));const u=this.shadow.getElementById("pfb-free-cancel-btn");u==null||u.addEventListener("mousedown",p=>p.preventDefault()),u==null||u.addEventListener("click",()=>{this.isFreeInputMode=!1,this.renderQuickInject()});const d=this.shadow.getElementById("pfb-tpl-back-btn");d==null||d.addEventListener("mousedown",p=>p.preventDefault()),d==null||d.addEventListener("click",()=>{this.isFreeInputMode=!1,this.renderQuickInject()});const c=this.shadow.getElementById("pfb-free-send-btn");c==null||c.addEventListener("mousedown",p=>p.preventDefault()),c==null||c.addEventListener("click",()=>{const p=l==null?void 0:l.value.trim();if(!p){this.showToast("⚠️ 请输入你想说的话！");return}this.close(),this.selectedModelForTemplate=null,this.isFreeInputMode=!1,this.renderQuickInject(),this.showToast(`🚀 正在套用自由输入接力至 ${n.toUpperCase()}...`),document.dispatchEvent(new CustomEvent("pfb:relay-request",{bubbles:!0,composed:!0,detail:{targetModel:n,skipTemplate:!0,templateId:void 0,customPrompt:p,capturedContent:this.capturedSelectionText}}))})}else{const n=this.selectedModelForTemplate,i=this.getBrandingColor(n),s=((e=v.find(d=>d.id===n))==null?void 0:e.name)||n,r=this.templates.filter(d=>d.targetModel===n);o.innerHTML=`
        <div class="pfb-template-select-header" style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
          <button id="pfb-tpl-back-btn" style="background:transparent; border:none; color:#8E8E93; cursor:pointer; font-size:12px; padding:4px 0; display:flex; align-items:center; gap:4px; font-weight:700;">
            ← 返回
          </button>
          <span style="font-size:10px; font-weight:700; color:${i}; letter-spacing:1px; text-transform:uppercase;">
            选择 ${s} 模板
          </span>
        </div>
        <div class="pfb-tpl-list" style="display:flex; flex-direction:column; gap:6px; margin-bottom:16px;">
          <button class="pfb-tpl-select-btn" data-direct="true" style="width:100%; text-align:left; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.08); border-radius:12px; padding:10px 14px; color:white; cursor:pointer; font-size:12px; font-weight:500; transition:all 0.2s;">
            ⚡ 直接发送 (无模板)
          </button>
          ${r.map(d=>`
            <button class="pfb-tpl-select-btn" data-tpl-id="${d.id}" style="width:100%; text-align:left; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.05); border-radius:12px; padding:10px 14px; color:white; cursor:pointer; font-size:12px; font-weight:500; transition:all 0.2s; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
              ${d.label}
            </button>
          `).join("")}
          <button class="pfb-tpl-select-btn" id="pfb-tpl-free-input-btn" style="width:100%; text-align:left; background:rgba(59,130,246,0.1); border:1px solid rgba(59,130,246,0.2); border-radius:12px; padding:10px 14px; color:#60A5FA; cursor:pointer; font-size:12px; font-weight:700; transition:all 0.2s; margin-top:4px;">
            ✍️ 自由输入 / 追加 Prompt
          </button>
        </div>
      `;const l=this.shadow.getElementById("pfb-tpl-back-btn");l==null||l.addEventListener("mousedown",d=>d.preventDefault()),l==null||l.addEventListener("click",()=>{this.selectedModelForTemplate=null,this.renderQuickInject()});const u=this.shadow.getElementById("pfb-tpl-free-input-btn");u==null||u.addEventListener("mousedown",d=>d.preventDefault()),u==null||u.addEventListener("click",()=>{this.isFreeInputMode=!0,this.renderQuickInject()}),o.querySelectorAll(".pfb-tpl-select-btn").forEach(d=>{d.id!=="pfb-tpl-free-input-btn"&&(d.addEventListener("mousedown",c=>c.preventDefault()),d.addEventListener("click",c=>{const p=c.currentTarget,m=p.dataset.direct==="true",h=p.dataset.tplId;if(this.close(),this.selectedModelForTemplate=null,this.renderQuickInject(),m)this.showToast(`⚡ 正在抓取并直接接力至 ${n.toUpperCase()}...`),document.dispatchEvent(new CustomEvent("pfb:relay-request",{bubbles:!0,composed:!0,detail:{targetModel:n,skipTemplate:!0,capturedContent:this.capturedSelectionText}}));else if(h){const g=p.innerText.trim();this.showToast(`🚀 正在套用「${g}」接力至 ${n.toUpperCase()}...`),document.dispatchEvent(new CustomEvent("pfb:relay-request",{bubbles:!0,composed:!0,detail:{targetModel:n,templateId:h,capturedContent:this.capturedSelectionText}}))}}))})}}initInteractions(){var o,e;(o=this.orb)==null||o.addEventListener("mousedown",t=>t.preventDefault()),(e=this.orb)==null||e.addEventListener("click",()=>this.toggle()),document.addEventListener("mousedown",t=>{!this.host.contains(t.target)&&this.isOpen&&this.close()})}initKeyboard(){window.addEventListener("keydown",o=>{const e=this.shadow.activeElement||document.activeElement;e&&(e.tagName==="TEXTAREA"||e.tagName==="INPUT")||(o.altKey&&o.code==="KeyR"&&this.pipelines[0]&&this.launch(this.pipelines[0]),o.key==="Escape"&&this.isOpen&&this.close(),this.isOpen&&(o.key==="Enter"||o.key==="Tab")&&this.recommendedPipeline&&(o.preventDefault(),o.stopPropagation(),this.launch(this.recommendedPipeline)))})}classifyIntent(o){const e=o.toLowerCase(),t=["paper","thesis","论文","research","academic","citation","文献","学术","摘要","abstract","experiment","实验"],n=["code","function","bug","refactor","重构","代码","算法","algorithm","math","公式","equation","programming","typescript","python","javascript","c++","java","rust","html","css","json","yaml"],i=["analysis","compare","versus","vs","辩论","分析","优缺点","pros and cons","利弊","观点","opinion","review","evaluation","对比"],s=["write","story","novel","idea","brainstorm","创意","写作","故事","小说","大纲","切入点","marketing","copywriting","文案","策划","剧本"];let r="general",l="💡 AI 智能推荐理由：检测到通用任务与深度校对需求。已自动为您编排：ChatGPT (初步方案生成) ➡️ Kimi (红蓝对抗深度挑刺) ➡️ DeepSeek (终审定稿)。";t.some(c=>e.includes(c))?(r="academic",l="💡 AI 智能推荐理由：检测到学术论文或事实调研意图。已自动为您编排：DeepSeek (学术逻辑深度评审) ➡️ Gemini (联网 facts 补充) ➡️ ChatGPT (地道英文/学术润色)。"):n.some(c=>e.includes(c))?(r="code",l="💡 AI 智能推荐理由：检测到复杂代码或数学公式逻辑。已自动为您编排：DeepSeek (核心逻辑高保真重构) ➡️ ChatGPT (最佳实践精修) ➡️ Grok (安全与边界审计)。"):i.some(c=>e.includes(c))?(r="debate",l="💡 AI 智能推荐理由：检测到多视角观点对比与风险解构意图。已自动为您编排：ChatGPT (正方乐观分析) ➡️ Grok (反方批判性审视) ➡️ Kimi (中立智库客观总结)。"):s.some(c=>e.includes(c))&&(r="creative",l="💡 AI 智能推荐理由：检测到极限发散与创意文案写作意图。已自动为您编排：Grok (极限脑洞发散) ➡️ ChatGPT (故事结构化大纲) ➡️ Gemini (感官情绪润色与精修)。");let u=null;const d=c=>this.pipelines.find(p=>{const m=p.name.toLowerCase();return c.some(h=>m.includes(h))});if(r==="academic"){const c=d(["学术","论文","academic","research"]);c&&(u=c.id)}else if(r==="code"){const c=d(["代码","重构","code","refactor"]);c&&(u=c.id)}else if(r==="debate"){const c=d(["辩论","分析","debate","analysis"]);c&&(u=c.id)}else if(r==="creative"){const c=d(["创意","写作","creative","write"]);c&&(u=c.id)}if(u){const c=this.pipelines.find(p=>p.id===u);if(c){const p=c.steps.map(m=>{var h;return((h=v.find(g=>g.id===m.target))==null?void 0:h.name)||m.target}).join(" ➡️ ");l=l.split("已自动为您编排")[0]+`已自动为您编排「${c.name}」：${p}。`}}else{const c=d(["审查","review","通用"]);if(c)u=c.id;else if(this.pipelines.length>0){u=this.pipelines[0].id;const p=this.pipelines[0].name,m=this.pipelines[0].steps.map(h=>{var g;return((g=v.find(S=>S.id===h.target))==null?void 0:g.name)||h.target}).join(" ➡️ ");l=`💡 AI 智能推荐理由：基于当前上下文意图评估，已匹配最适用的工作流管线「${p}」：${m}。`}}return{category:r,rationale:l,pipelineId:u}}getLastUserQuery(){const o=['div[data-message-author-role="user"]',"div.ds-message--user",'div[class*="ds-message--user"]','div[class*="user-message"]',".chat-item.user",".user-msg",".user-message","user-query",".query-text",'div[data-testid="user-message"]',".font-user-message",'div[class*="user"][class*="message"]','div[class*="Message"][class*="User"]','div[class*="query"]'];for(const t of o){const n=document.querySelectorAll(t);if(n.length>0){const i=n[n.length-1],r=(i.innerText||i.textContent||"").trim();if(r)return r}}const e=document.querySelectorAll('textarea, div[contenteditable="true"]');for(let t=e.length-1;t>=0;t--){const n=e[t];if(n.id&&n.id.includes("pfb-"))continue;let i="";if(n instanceof HTMLTextAreaElement?i=n.value.trim():i=n.innerText.trim(),i)return i}return""}analyzeDynamicIntent(o,e=""){const t=o.toLowerCase().trim(),n=e.toLowerCase().trim(),i=t;if(!t||t.length<5)return{dynamicPipeline:null,rationale:""};const s=(w,T)=>n&&w.some(y=>n.includes(y))?!0:w.some(y=>t.includes(y))?!(n&&n.length<30&&(T==="search"&&!["查","搜","最新","实时","search","fetch","latest","news"].some(y=>n.includes(y))||T==="reasoning"&&!["代码","编程","算法","数学","公式","推导","code","function","math","formula","algorithm","代码实现","算法实现","重构","debug","纠错","typescript","python","javascript","c++","rust","java","structure","write a","implement"].some(y=>n.includes(y))||T==="polish"&&!["润色","翻译","优化","精修","英文","polish","translate","english","refine","rewrite","文笔","写作","改写"].some(y=>n.includes(y))||T==="audit"&&!["审计","挑刺","红蓝","安全","audit","critique","security","漏洞","找错","测试","风险"].some(y=>n.includes(y)))):!1,r=s(["查","搜","最新","实时","背景","文献","search","fetch","latest","info","news","调查","了解"],"search"),l=s(["代码","编程","算法","数学","公式","推导","code","function","math","formula","algorithm","代码实现","算法实现","重构","debug","纠错","typescript","python","javascript","c++","rust","java","structure","write a","implement"],"reasoning"),u=s(["润色","翻译","优化","精修","英文","polish","translate","english","refine","rewrite","文笔","写作","改写"],"polish"),d=s(["审计","挑刺","红蓝","安全","audit","critique","security","漏洞","找错","测试","风险"],"audit"),c=[],p=[];if(r&&(c.push({target:"kimi",templateBody:`【AI 动态编排 · 阶段 1：高时效实时搜索】
请针对以下核心主题与需求，利用你的全网实时检索与长文本抓取能力，搜集最新、最权威的事实、背景数据及相关参考资料：

<Original_Topic>
{{seed}}
</Original_Topic>

指令：请精简整理搜集到的事实，忽略冗余杂音，以结构化的点状列表输出。`,outputVar:"search_facts",autoSend:!0}),p.push("Kimi (时效数据检索)")),l){const w=c.length+1,T=c.length>0?`

【参考前置检索事实】:
{{search_facts}}`:"";c.push({target:"deepseek",templateBody:`【AI 动态编排 · 阶段 ${w}：深度逻辑推理与实现】
请针对用户的原始需求进行最严密、最详尽的深度思考与代码/数学模型实现。${T}

<Original_Request>
{{seed}}
</Original_Request>

指令：展示你的深度逻辑思考过程（Chain of Thought），并输出最优雅、最高效的完整实现方案。`,outputVar:"logic_solution",autoSend:!0}),p.push("DeepSeek (深度逻辑推理/代码实现)")}if(u){const w=c.length+1,T=c.length>0?c[c.length-1].outputVar:"seed";c.push({target:"gpt",templateBody:`【AI 动态编排 · 阶段 ${w}：顶级学术与文案润色】
请作为顶级期刊的特邀资静编辑，对以下内容进行深度重构与文案美化：

<Draft_Content>
{{${T}}}
</Draft_Content>

指令：修复所有的文笔生硬、逻辑不连贯处，确保语言地道、用词精准、结构优雅。直接输出润色后的完美终稿，无需客套。`,outputVar:"polished_final",autoSend:!0}),p.push("ChatGPT (文案/英文极致精修)")}if(d){const w=c.length+1,T=c.length>0?c[c.length-1].outputVar:"seed";c.push({target:"grok",templateBody:`【AI 动态编排 · 阶段 ${w}：红蓝对抗与安全/边界审计】
你是一位极度严苛、拥有极致对抗思维的安全与质量审计专家。请对以下方案/代码进行全方位的“挑刺”与逻辑重压测试：

<Target_Implementation>
{{${T}}}
</Target_Implementation>

指令：
1. 指出最致命的边界安全缺陷、溢出风险或逻辑漏洞。
2. 直接给出修复后的最终安全版代码或防范策略。`,outputVar:"final_audited",autoSend:!0}),p.push("Grok (红蓝对抗与安全审计)")}if(c.length===1){const w=c[0].target;w==="deepseek"?(c.push({target:"grok",templateBody:`【AI 动态编排 · 阶段 2：安全与边界审计】
请对前置阶段生成的代码方案进行严苛的边界条件压力测试，列出 3 个潜在逻辑隐患，并输出修复后的终版本：

{{logic_solution}}`,outputVar:"final_audited",autoSend:!0}),p.push("Grok (安全与边界审计)")):w==="kimi"?(c.push({target:"gpt",templateBody:`【AI 动态编排 · 阶段 2：核心纲要提炼】
请将前置检索到的庞杂资料精简、归纳为 3 个可以直接汇报的核心纲要，文风保持严谨利落：

{{search_facts}}`,outputVar:"final_summary",autoSend:!0}),p.push("ChatGPT (核心纲要提炼)")):(c.push({target:"deepseek",templateBody:`【AI 动态编排 · 阶段 2：深度逻辑交叉核验】
请用你强大的推理能力核算以下草稿中的事实论点是否完全无懈可击，如有漏洞请予以更正：

{{last}}`,outputVar:"final_verified",autoSend:!0}),p.push("DeepSeek (逻辑核验)"))}c.length===0&&(i.length>80?(c.push({target:"kimi",templateBody:`【AI 动态编排 · 阶段 1：长文脉络提炼】
请阅读并深入分析以下长文背景，提炼出其最核心的 3 个技术脉络或论证要点：

<Content>
{{seed}}
</Content>`,outputVar:"facts_outline",autoSend:!0}),p.push("Kimi (长文脉络提炼)"),c.push({target:"deepseek",templateBody:`【AI 动态编排 · 阶段 2：技术可行性与逻辑校对】
请针对以下提炼出的核心脉络，核验其底层的技术可行性或是否存在逻辑漏洞，并给出你的深度补充说明：

<Outline>
{{facts_outline}}
</Outline>

<Original>
{{seed}}
</Original>`,outputVar:"logic_check",autoSend:!0}),p.push("DeepSeek (技术可行性/逻辑校对)"),c.push({target:"gpt",templateBody:`【AI 动态编排 · 阶段 3：高阶演讲与汇报总结】
请综合上述分析，将其重构为一份高阶、通俗易懂的汇报概要，字数控制在 200 字内：

{{logic_check}}`,outputVar:"final_report",autoSend:!0}),p.push("ChatGPT (高阶汇报总结)")):(c.push({target:"deepseek",templateBody:`【AI 动态编排 · 阶段 1：核心命题深度推理】
请针对以下核心命题进行一步步的深入逻辑推演（Chain of Thought），给出你深刻的见解或解题思路：

{{seed}}`,outputVar:"reasoned_ans",autoSend:!0}),p.push("DeepSeek (命题深度推理)"),c.push({target:"gpt",templateBody:`【AI 动态编排 · 阶段 2：输出文笔精修】
请将上述深度推理的结论进行排版优化与润色，使其更具可读性与情绪感染力：

{{reasoned_ans}}`,outputVar:"polished_final",autoSend:!0}),p.push("ChatGPT (文案美化/润色)")));const m=p.join(" ➡️ "),h=[];r&&h.push("时效数据检索"),l&&h.push("深度数据建模/代码实现"),u&&h.push("文本文笔精修"),d&&h.push("红蓝对抗安全审计"),h.length===0&&(i.length>80?h.push("通用长文剖析","技术可行性分析","高阶汇报总结"):h.push("短文本命题推理","文案润色"));const S=`💡 AI 智能动态编排理由：检测到「${h.join("、")}」的复合任务。已现场为您个性化编排最佳接力链路：${m}。`;return{dynamicPipeline:{id:"pfb-dynamic-pipeline",name:"✨ AI 智能动态编排链",steps:c},rationale:S}}renderPipelines(){const o=this.shadow.getElementById("pfb-list");if(!o)return;const e=this.getLastUserQuery(),t=this.analyzeDynamicIntent(this.capturedSelectionText,e);let n=[...this.pipelines],i=null,s="";if(t.dynamicPipeline)n=[t.dynamicPipeline,...n],i="pfb-dynamic-pipeline",this.recommendedPipeline=t.dynamicPipeline,s=t.rationale;else{const r=this.classifyIntent(this.capturedSelectionText);i=r.pipelineId,this.recommendedPipeline=this.pipelines.find(l=>l.id===r.pipelineId)||null,s=r.rationale}o.innerHTML=n.map(r=>{const l=r.id==="pfb-dynamic-pipeline",u=r.id===i;let d="";l?d='<span class="ai-badge gold">✨ AI 动态编排</span>':u&&(d='<span class="ai-badge">AI 推荐</span>');const c=u||l?`<div class="recommended-tooltip">${s}</div>`:"";return`
        <button class="pipeline-item ${l?"dynamic-assembled":u?"recommended":""}" data-id="${r.id}">
          <div class="item-header">
            <span class="item-name">${r.name} ${d}</span>
          </div>
          <div class="item-steps">
            ${r.steps.map((p,m)=>`
              <div class="step-dot" style="background:${this.getBrandingColor(p.target)}">${this.getChar(p.target)}</div>
              ${m<r.steps.length-1?'<span class="step-arrow">→</span>':""}
            `).join("")}
          </div>
          ${c}
        </button>
      `}).join(""),o.querySelectorAll(".pipeline-item").forEach(r=>{r.addEventListener("mousedown",l=>l.preventDefault()),r.addEventListener("click",l=>{const u=l.currentTarget.dataset.id,d=n.find(c=>c.id===u);d&&this.launch(d)})})}async loadPipelines(){var o,e;try{if(!((o=chrome==null?void 0:chrome.storage)!=null&&o.local)||!((e=chrome==null?void 0:chrome.runtime)!=null&&e.id))return;const t=await chrome.storage.local.get(["pfb_pipelines"]);this.pipelines=t.pfb_pipelines||[],this.renderPipelines()}catch(t){console.warn("[Relay] Failed to load pipelines:",t)}}launch(o){this.close(),this.setStatus("running"),document.dispatchEvent(new CustomEvent("pfb:pipeline-start",{bubbles:!0,composed:!0,detail:{pipeline:o}}))}getBrandingColor(o){var e;return((e=v.find(t=>t.id===o))==null?void 0:e.color)||"#3B82F6"}getChar(o){var e;return((e=v.find(t=>t.id===o))==null?void 0:e.char)||"?"}setStatus(o){this.status=o,this.orb&&(this.orb.className=o)}syncState(){var o;try{if(!((o=chrome==null?void 0:chrome.runtime)!=null&&o.id))return;chrome.storage.local.get(["pfb_pipeline_state"]).then(e=>{const t=e.pfb_pipeline_state;(t==null?void 0:t.status)==="running"&&this.setStatus("running")}).catch(()=>{})}catch{}}loadAndRefresh(){var o;try{if(!((o=chrome==null?void 0:chrome.runtime)!=null&&o.id))return;chrome.storage.local.get(["pfb_pipeline_state"]).then(e=>{const t=e.pfb_pipeline_state;t&&this.setStatus(t.status)}).catch(()=>{})}catch{}}listenToEvents(){var o,e;try{if(!((o=chrome==null?void 0:chrome.runtime)!=null&&o.onMessage))return;chrome.runtime.onMessage.addListener(t=>{try{(t.type==="PIPELINE_STATUS_UPDATE"||t.type==="PIPELINE_STEP_DONE")&&this.loadAndRefresh(),t.type==="PIPELINE_COMPLETE"&&(this.setStatus("idle"),this.showToast("🎉 Relay Complete"))}catch{}}),(e=chrome==null?void 0:chrome.storage)!=null&&e.onChanged&&chrome.storage.onChanged.addListener(t=>{t.pfb_templates&&this.loadTemplates().then(()=>{this.renderQuickInject()})})}catch{}}showToast(o,e=3e3){const t=this.shadow.getElementById("pfb-toast");t&&(t.innerText=o,t.classList.add("visible"),e>0&&setTimeout(()=>t.classList.remove("visible"),e))}showActionToast(o,e,t){const n=this.shadow.getElementById("pfb-toast");if(n){n.innerHTML=`<span>${o}</span> <button id="pfb-toast-action" style="background:#3B82F6; border:none; color:white; border-radius:12px; padding:4px 12px; margin-left:12px; cursor:pointer; font-size:11px; font-weight:900; box-shadow:0 4px 12px rgba(59,130,246,0.3);">${e}</button>`,n.classList.add("visible");const i=this.shadow.getElementById("pfb-toast-action");i==null||i.addEventListener("click",s=>{s.stopPropagation(),t(),n.classList.remove("visible")})}}toggle(){this.isOpen?this.close():this.open()}open(){var e,t;this.isOpen=!0,(e=this.panel)==null||e.classList.remove("hidden");const o=(t=window.getSelection())==null?void 0:t.toString().trim();o&&(this.capturedSelectionText=o),this.renderPipelines()}close(){var o;this.isOpen=!1,(o=this.panel)==null||o.classList.add("hidden"),this.selectedModelForTemplate=null,this.isFreeInputMode=!1,this.recommendedPipeline=null,this.capturedSelectionText="",this.renderQuickInject()}updateSession(o,e){}}console.log("[PromptFlow Bridge] Content Script Initializing...");let b=!1;function C(){if(b)return;console.warn("[PromptFlow Bridge] ⚠️ Extension context invalidated. Service worker disconnected."),b=!0;const a=I();if(a){a.showToast("⚠️ 插件已更新或连接中断，请刷新当前页面以恢复接力功能",0);const o=document.querySelector(".pfb-dynamic-island-host");if(o!=null&&o.shadowRoot){const e=o.shadowRoot.getElementById("pfb-orb");e&&(e.style.filter="grayscale(1) opacity(0.5)",e.style.cursor="not-allowed")}}}window.addEventListener("error",a=>{var o;(o=a.message)!=null&&o.includes("Extension context invalidated")&&C()},!0);window.addEventListener("unhandledrejection",a=>{var o,e;(e=(o=a.reason)==null?void 0:o.message)!=null&&e.includes("Extension context invalidated")&&C()});let R;var $;try{R=($=chrome==null?void 0:chrome.runtime)==null?void 0:$.id}catch{b=!0}setInterval(()=>{var a,o;try{(((a=chrome==null?void 0:chrome.runtime)==null?void 0:a.id)!==R||!((o=chrome==null?void 0:chrome.runtime)!=null&&o.id))&&(b||C())}catch{b=!0}},1e3);const x=()=>{var a,o;return!b&&!!((a=chrome==null?void 0:chrome.runtime)!=null&&a.id&&((o=chrome==null?void 0:chrome.storage)!=null&&o.local))};function I(){return!D&&document.body&&x()&&(D=new K),D}function Q(){const a=window.location.href.toLowerCase();return a.includes("deepseek.com")?"deepseek":a.includes("kimi.com")||a.includes("kimi.ai")||a.includes("kimi.moonshot")?"kimi":a.includes("gemini.google.com")?"gemini":a.includes("chatgpt.com")||a.includes("chat.openai.com")?"gpt":a.includes("grok.com")||a.includes("x.com/i/grok")?"grok":"unknown"}async function E(a){var e;if(b||!((e=chrome==null?void 0:chrome.runtime)!=null&&e.id))return null;if(["PIPELINE_STEP_DONE","CONTENT_CAPTURED","START_PIPELINE"].includes(a.type))try{window.localStorage.setItem("pfb_shadow_copy",JSON.stringify(a))}catch{console.warn("[PromptFlow Bridge] Shadow copy failed")}return new Promise(t=>{try{chrome.runtime.sendMessage(a,n=>{if(chrome.runtime.lastError){(chrome.runtime.lastError.message||"").includes("Extension context invalidated")&&(b=!0,C()),t(null);return}(a.type==="PIPELINE_STEP_DONE"||a.type==="PIPELINE_ERROR"||a.type==="CONTENT_CAPTURED")&&window.localStorage.removeItem("pfb_shadow_copy"),t(n)})}catch{b=!0,C(),t(null)}})}const X=[new G,new O,new z,new H,new U];let q=null,D=null,_=null;document.addEventListener("contextmenu",a=>{_=a.target},!0);function A(){return q||(q=X.find(a=>a.detect())||null,q)}async function Y(a,o,e){e.showToast("✅ 注入成功，正在自动发送...",2e3),setTimeout(async()=>{if(!b)try{const t=await o.send();e.showToast(t?"🎉 单次接力完成！":"⚠️ 请手动点击发送",t?3e3:5e3)}catch(t){b||console.error("[Relay] Error in single relay:",t)}},800)}async function J(a,o,e,t){const n=t.currentStepIndex+1,i=t.totalSteps;if(b)return;e.showToast(`🔗 步骤 ${n}/${i} · 正在准备发送...`);let s;if(await o.send())e.showToast(`🔗 步骤 ${n}/${i} · 等待回答中...`),s=await o.waitForResponseComplete();else{e.showToast("⚠️ 自动发送被阻截（按钮未激活或被禁用），请手动点击");const l=await o.waitForResponseComplete(1500,6e5);if(l.text)s=l;else{await E({type:"PIPELINE_ERROR",error:{type:"hard",message:"自动发送失败或被阻截，请重试"}});return}}if(!b){if(s.error){const l=s.error.type==="hard";e.showToast(`🛑 ${l?"故障":"提醒"}: ${s.error.message}`),await E({type:"PIPELINE_ERROR",error:{...s.error,snapshotHtml:l?document.body.innerHTML.slice(0,5e3):void 0}});return}s.text?(e.showToast(`✅ 步骤 ${n} 完成！正在转发...`),await E({type:"PIPELINE_STEP_DONE",stepIndex:t.currentStepIndex,responseText:s.text,outputVar:t.context.__currentOutputVar||"last"})):e.showToast("⚠️ 未能自动捕获回答，流程暂停")}}async function F(a){if(!x())return;try{await chrome.storage.local.set({pfb_state:{stage:"idle"}})}catch(i){console.warn("[Relay] Failed to clear injection stage state:",i)}const o=A(),e=I();if(!o||!e){console.warn("[Relay] No adapter found or context invalid");return}if(e.showToast(`⚡ 正在注入来自 ${a.sourceModel} 的内容...`),!await o.inject(a.content)){e.showToast("❌ 注入失败，请手动粘贴");return}await E({type:"CONFIRM_SESSION",modelType:o.platform,url:window.location.href}),e.updateSession&&e.updateSession(o.platform,!0);const n=await W();(n==null?void 0:n.status)==="running"?await J(a,o,e,n):await Y(a,o,e)}async function W(){if(!x())return null;try{return(await chrome.storage.local.get(["pfb_pipeline_state"])).pfb_pipeline_state||null}catch{return b=!0,null}}async function N(a,o,e,t,n){var u;if(!x())return;try{await chrome.storage.local.remove("pfb_pipeline_state")}catch{b=!0;return}const i=A(),s=I();if(!s)return;s.showToast("📋 正在抓取内容...");let r=n!==void 0?n:(u=window.getSelection())==null?void 0:u.toString().trim(),l;if(r?l={content:r,sourceModel:i?i.platform:"unknown",hasLaTeX:r.includes("$")||r.includes("\\"),timestamp:Date.now()}:i?l=i.capture(_||void 0)||{content:"",sourceModel:i.platform,hasLaTeX:!1,timestamp:Date.now()}:l={content:"",sourceModel:"unknown",hasLaTeX:!1,timestamp:Date.now()},!l.content.trim()&&i&&!t){const d=document.querySelector('[role="assistant"]:last-of-type')||document.querySelector(".prose:last-of-type")||document.querySelector('[class*="response"]:last-of-type');d&&(l.content=i.getCleanText(d),d.style.outline="2px dashed #ff9900",setTimeout(()=>d.style.outline="",2e3),s.showToast("ℹ️ 未选中内容，已自动抓取最新回答"))}if(t){const d=l.content.trim();d?l.content=`${t}

---
【参考上下文】：
${d}`:l.content=t,e=!0,o=void 0}l.content.trim()?(E({type:"CONTENT_CAPTURED",payload:l,targetModel:a,templateId:o,skipTemplate:e}),s.showToast(`🚀 已发送至 ${a}，等待跳转...`)):s.showToast("⚠️ 无法识别内容，请手动选中文字后重试")}async function Z(a){var n,i;if(!x())return;const o=A(),e=I();if(!e)return;e.showToast(`🔗 启动链路：${a.name}...`);let t=((n=window.getSelection())==null?void 0:n.toString().trim())||((i=o==null?void 0:o.capture(_||void 0))==null?void 0:i.content)||"";if(!t.trim()){const s=document.querySelector('[role="assistant"]:last-of-type')||document.querySelector(".prose:last-of-type");s&&o&&(t=o.getCleanText(s),s.style.outline="2px dashed #ff9900",setTimeout(()=>s.style.outline="",2e3))}if(!t.trim()){e.showToast("⚠️ 请先选中要接力的内容或右键具体回答");return}await E({type:"START_PIPELINE",pipelineId:a.id,seedContent:t,pipeline:a})}async function ee(a,o){if(!x())return;const{pfb_pipelines:e}=await chrome.storage.local.get(["pfb_pipelines"]);(e||[]).find(i=>i.id===a)&&await E({type:"START_PIPELINE",pipelineId:a,seedContent:o})}document.addEventListener("pfb:relay-request",a=>{const o=a.detail;N(o.targetModel,o.templateId,o.skipTemplate,o.customPrompt,o.capturedContent)});document.addEventListener("pfb:pipeline-start",a=>{Z(a.detail.pipeline)});x()&&chrome.runtime.onMessage.addListener((a,o,e)=>x()?(a.type==="TRIGGER_CAPTURE"&&(N(a.targetModel,a.templateId,a.skipTemplate),e({status:"capturing"})),a.type==="INJECT_PAYLOAD"&&(F(a.payload),e({status:"injecting"})),!0):!1);async function te(){if(x())for(let a=0;a<15&&!b;a++){try{const{pfb_state:o}=await chrome.storage.local.get(["pfb_state"]),e=Q();if(o&&o.stage==="injecting"&&o.targetModel===e){console.log(`[Relay] Detected pending injection for ${e}. Executing...`),(e==="gpt"||e==="gemini")&&await new Promise(t=>setTimeout(t,2e3)),await F(o.payload);return}}catch{b=!0;break}await new Promise(o=>setTimeout(o,1500))}}async function ne(){const a=window.localStorage.getItem("pfb_shadow_copy");if(!a)return;let o;try{o=JSON.parse(a)}catch{return}const e=I();if(!e)return;let t="任务";if(x()){const{pfb_pipeline_state:n}=await chrome.storage.local.get(["pfb_pipeline_state"]);t=(n==null?void 0:n.currentPipelineName)||"任务"}e.showActionToast(`恢复中断的「${t}」`,"继续接力",async()=>{window.localStorage.removeItem("pfb_shadow_copy"),o.type==="START_PIPELINE"?await ee(o.pipelineId,o.seedContent):(o.type==="PIPELINE_STEP_DONE"||o.type==="CONTENT_CAPTURED")&&(await E(o),e.showToast("✅ 已恢复进度，正在跳转..."))})}function M(){setTimeout(()=>{try{I()&&ne()}catch{}},1e3),x()&&te().catch(()=>{})}try{document.readyState==="complete"?M():window.addEventListener("load",M)}catch{}
})()
